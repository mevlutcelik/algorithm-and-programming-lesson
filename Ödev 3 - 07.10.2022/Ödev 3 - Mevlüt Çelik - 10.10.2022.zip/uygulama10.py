# Mevlüt Çelik
# 07.10.2022
# type komutu python da ne işe yaramaktadır internetten araştırıp tüm veri tiplerinden vereceğiniz örnekle açıklayınız.


# id() metodu o nesnenin kimliğini döndürür. Her nesneye (değişkene, objeye, classa) ait uniq bir kimlik değeri döner.


dizi = id(('Türkçe', 'Matematik', 'Fizik'))

print(dizi)