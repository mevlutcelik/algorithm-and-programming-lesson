# Mevlüt Çelik
# 07.10.2022
# Python da veri tipleri nelerdir yazınız.

# String: Karakter Dizisi
# Integer: Tam Sayı
# Float: Ondalıklı Sayı
# Boolean: Mantıksal Veri Tipi
# List: Dizi Veri Tipi
# Bytes: Binary Veri Tipi