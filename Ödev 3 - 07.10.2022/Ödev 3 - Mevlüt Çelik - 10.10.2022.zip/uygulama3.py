# Mevlüt Çelik
# 07.10.2022
# Pythonda aritmetik operatörler nelerdir yazınız. 

# Toplama (+)
# Çıkarma (-)
# Çarpma (*)
# Üs Alma (**)
# Bölme (/)
# Tam Bölme (//)
# Mod Alma (%)