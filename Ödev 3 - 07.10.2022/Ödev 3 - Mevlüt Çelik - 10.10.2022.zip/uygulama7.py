# Mevlüt Çelik
# 07.10.2022
# Kullanıcıdan küpün 1 kenar uzunluğunu alarak alanını ve hacmini hesaplayarak sonucu ekrana yazdıran programı yazınız.


kenar = float(input("Küpün kenar uzunluğunu giriniz: "))
hacim = str(kenar ** 3)
alan = str(6 * (kenar ** 2))


print("Küpün hacmi: " + hacim)
print("Küpün alanı: " + alan)