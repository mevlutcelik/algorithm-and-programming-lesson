# Mevlüt Çelik
# 07.10.2022
# 1011 1101 sayısının 10 luk tabanda karşılığını hesaplayan programı yazınız.

soru = "1011 1101 sayısının 10 luk tabandaki karşılığı: "
islem = str((2 ** 0) + (2 ** 2) + (2 ** 3) + (2 ** 4) + (2 ** 5) + (2 ** 7))
print(soru + islem)