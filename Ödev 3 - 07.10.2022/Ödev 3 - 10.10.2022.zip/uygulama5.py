# Mevlüt Çelik
# 07.10.2022
# Kullanıcıdan üçgenin kenar uzunluklarını alarak çevresini hesaplayan ve sonucu ekrana yazdıran programı yazınız.


kenar1 = float(input("Üçgenin 1. kenar uzunluğunu giriniz: "))
kenar2 = float(input("Üçgenin 2. kenar uzunluğunu giriniz: "))
kenar3 = float(input("Üçgenin 3. kenar uzunluğunu giriniz: "))
cevre = str(kenar1 + kenar2 + kenar3)


print("Üçgenin çevresinin uzunluğu: " + cevre)