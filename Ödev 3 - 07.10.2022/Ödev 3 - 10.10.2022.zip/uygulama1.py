# Mevlüt Çelik
# 07.10.2022
# Adınız soyadınız, tarih, dersin kodu verilerini değişkene aktararak ekrana yazdırınız.


adsoyad = "Mevlüt Çelik"
tarih = "07.10.2022"
kod = "BST 103"


# Ekrana yazdıralım
print("Ad Soyad: " + adsoyad)
print("Tarih: " + tarih)
print("Dersin Kodu: " + kod)